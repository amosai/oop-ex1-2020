package MyTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WGraph_AlgoTest {

	@Test
	void testInit() {
		fail("Not yet implemented");
	}

	@Test
	void testGetGraph() {
		fail("Not yet implemented");
	}

	@Test
	void testCopy() {
		fail("Not yet implemented");
	}

	@Test
	void testDjikstra() {
		fail("Not yet implemented");
	}

	@Test
	void testIsConnected() {
		fail("Not yet implemented");
	}

	@Test
	void testShortestPathDist() {
		fail("Not yet implemented");
	}

	@Test
	void testShortestPath() {
		fail("Not yet implemented");
	}

	@Test
	void testSave() {
		fail("Not yet implemented");
	}

	@Test
	void testLoad() {
		fail("Not yet implemented");
	}

}
